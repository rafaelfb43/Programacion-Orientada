#include "Item.h"

Item::Item()
{
    this-> name = "NONE";
    this->buyValue = 0;
    this->sellValue = 0;

}

Item::~Item(){

}