#ifdef Room_hpp
#define Room_hpp

#include <iostream>
#include <string>
using namespace std;

struct Room
{
    Room();
    Room(string name, string description);
    void setVecino(Room* ptrNorte, Room* ptrSur, Room* ptrEste, Room* ptrOeste);
    void Setup(string name = "", string description);
    void OutputRoomInfo();
    void OutputVecino();

    string name;
    string description;
    Room* ptrVecinoNorte;
    Room* ptrVecinoSur;
    Room* ptrVecinoEste;
    Room* ptrVecinoOeste;
    
    /* data */
};


#endif