#pragma once

#include "Character.h"
#include "Functions.h"
#include <iostream>
#include <iomanip>
#include <ctime>

using namespace std;

class Game
{
public:
    Game();
    virtual ~Game();

    //Operadores

    //Funciones
    void initGame();
    void mainMenu();

    //Accessors
    inline bool getPlaying() const { return this -> playing; }

private:
    int choice;
    bool playing;


    //Character related
    Character character;
};