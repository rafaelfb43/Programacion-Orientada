#pragma once
#include <iostream>
#include "Inventory.h"

#include <string>
using namespace std;

class Character
{
public:
    Character();
    virtual ~Character();

    //Functions
    void initialize(const string name);
    void printStats() const;
    void levelUp();

    //Accesories
    inline const double& getX() const{ return this->xPos; }
    inline const double& getY() const{ return this->yPos; }

    inline const string& getName() const{ return this->name; }
    inline const int& getLevel() const{ return this->level; }
    inline const int& getexp() const{ return this->exp; }
    inline const int& getexpNext() const{ return this->expNext; }
    inline const int& gethp() const{ return this->hp; }
    inline const int& gethpMax() const{ return this->hpMax; }
    inline const int& getstamina() const{ return this->stamina; }
    inline const int& getdamageMin() const{ return this->damageMin; }
    inline const int& getdamageMax() const{ return this->damageMax; }
    inline const int& getdefence() const{ return this->defence; }


    //Modifier


private:
    double xPos;
    double yPos;

    string name;
    int level;
    int exp;
    int expNext;

    int strenght;
    int vitality;
    int dexterity;
    int intelligence;

    int hp;
    int hpMax;
    int stamina;
    int staminaMax;
    int damageMin;
    int damageMax;
    int defence;
    int luck;


    int statPoints;
    int skillPoints;


};