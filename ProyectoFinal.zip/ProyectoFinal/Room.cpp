#include "Room.h"
#ifdef Room_hpp
#define Room_hpp
using namespace std;


Room::Room(){
    Setup();
}

Room::Room(string name, string description){
    Setup(name, description);
}

void Room::Setup(string name, string description){

    this->name = name;
    this->description = description;

    ptrVecinoNorte = nullptr;
    ptrVecinoSur = nullptr;
    ptrVecinoEste = nullptr;
    ptrVecinoOeste = nullptr;


}

void Room::SetVecino(Room* ptrNorte, Room* ptrSur, Room* ptrEste, Room* ptrOeste){
    ptrVecinoNorte = ptrNorth;
    ptrVecinoSur = ptrSur;
    ptrVecinoEste = ptrEste;
    ptrVecinoOeste = ptrOeste;
    
}

void Room::OutputRoomInfo(){
    cout<< name << endl << description << endl;
    OutputVecino();
    cout<<endl;
}

void Room::OutputVecino(){
    cout<<"Puedes Comenzar: ";
    if ( ptrVecinoNorte != nullptr ){ cout << "Norte ";}
    if ( ptrVecinoSur != nullptr ){ cout << "Sur ";}
    if ( ptrVecinoEste != nullptr ){ cout << "Este ";}
    if ( ptrVecinoOeste != nullptr ){ cout << "Oeste ";}

    cout << endl;
    

}

#endif